#include <string.h>





void packetParse(char* pkt);



