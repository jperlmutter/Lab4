#ifndef __TIMER1INTS_H__ // do not include more than once
#define __TIMER1INTS_H__
#include <stdint.h>
// ***************** Timer1_Init ****************
// Activate Timer1 interrupts to run user task periodically
// Inputs:  task is a pointer to a user function
//          period in units (1/clockfreq)
// Outputs: none
void Timer1_Init(void);

void Timer1_StartWatch(void);

uint32_t Timer1_StopWatch(void);

#endif // __TIMER2INTS_H__