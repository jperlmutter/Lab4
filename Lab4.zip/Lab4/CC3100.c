#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include "ST7735.h"

char temperature[7];
char tempnum[6];
void packetParse(char* pkt){
	char* temp = "\"temp\"";
	int counter = 0;
	while(pkt[counter] != 0)
	{
		if(pkt[counter]=='t'  && pkt[counter+1]=='e' && pkt[counter+2]=='m' && pkt[counter+3]=='p' && pkt[counter+4]=='\"'  )
		{
			tempnum[0] = pkt[counter+6];
			tempnum[1] = pkt[counter+7];
			tempnum[2] = pkt[counter+8];
			tempnum[3] = pkt[counter+9];
			tempnum[4] = pkt[counter+10];
			tempnum[5] = 0;
		}
		counter++;
		
	}
	
	ST7735_OutString("Temp: ");
	
	ST7735_OutString(tempnum);
	ST7735_OutString(" F");
	
}




